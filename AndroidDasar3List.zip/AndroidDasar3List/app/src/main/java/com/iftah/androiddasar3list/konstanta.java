package com.iftah.androiddasar3list;

public class konstanta {
    public static final String DATANAMA = "datanama";
    public static final String DATAGAMBAR = "datagambar" ;
}
